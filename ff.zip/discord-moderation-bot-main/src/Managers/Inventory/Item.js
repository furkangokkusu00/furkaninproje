class Item {
    constructor(id, name, description, type, symbol){
        this.Id = id;
        this.Name = name;
        this.Description = description;
        this.Type = type;
        this.Symbol = symbol;
    }
}

module.exports = Item;