class UserItem {
    constructor(id, count){
        this.Id = id;
        this.Count = count;
    }
}

module.exports = UserItem;